package com.eepromtool

import android.app.Activity
import android.os.Bundle
import android.widget.*
import android.content.Intent
import android.net.Uri

class MainActivity : Activity() {
    // Funktionale Implementierung hier
}